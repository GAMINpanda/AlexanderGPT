import re
import sqlite3
from contextlib import closing


STOP_WORDS = set(
    "about again also and are can could did does for from had has have how into "
    "just more please should tell than that the their them then there these they "
    "this use used using want was were what when where which who why will with would you your".split()
)


class ChatMemory:
    def __init__(self, path):
        self.path = path
        with closing(sqlite3.connect(path)) as db:
            db.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS turns USING fts5("
                "conversation UNINDEXED, turn UNINDEXED, prompt, reply, summary UNINDEXED)"
            )

    def latest(self, conversation):
        with closing(sqlite3.connect(self.path)) as db:
            row = db.execute(
                "SELECT summary FROM turns WHERE conversation = ? ORDER BY rowid DESC LIMIT 1",
                (conversation,),
            ).fetchone()
        return row[0] if row else ""

    def remember(self, conversation, turn, prompt, reply, summary):
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute(
                "SELECT summary FROM turns WHERE conversation = ? AND turn = ?", (conversation, turn)
            ).fetchone()
            if existing:
                summary = existing[0]
            else:
                db.execute("INSERT INTO turns VALUES (?, ?, ?, ?, ?)",
                           (conversation, turn, prompt, reply, summary))
            count = db.execute("SELECT count(*) FROM turns WHERE conversation = ?", (conversation,)).fetchone()[0]
        return summary, count

    def recall(self, conversation, prompt):
        words = dict.fromkeys(
            word for word in re.findall(r"[^\W_]{3,}", prompt.lower())
            if word not in STOP_WORDS
        )
        terms = " OR ".join(f'"{word}"' for word in list(words)[:24])
        if not terms:
            return []
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute(
                "SELECT snippet(turns, 2, '', '', ' … ', 24), "
                "snippet(turns, 3, '', '', ' … ', 36) "
                "FROM turns WHERE turns MATCH ? AND conversation = ? "
                "ORDER BY bm25(turns, 0, 0, 2, 1), rowid DESC LIMIT 2",
                (terms, conversation),
            ).fetchall()
        return [f"Earlier user: {prompt[:220]}\nEarlier reply: {reply[:320]}" for prompt, reply in rows]
